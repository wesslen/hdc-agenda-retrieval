Title: 

URL Source: https://wesslen.github.io/hdc-agenda-retrieval/data/supplement/2024/01_agenda-supplement_may-8-2024.pdf

Markdown Content:
# Agenda Supplement May 8, 2024 

## HDC Meeting 

# Applicant Submitted Information ADDED BUMP OUT DIMENSION 

> ON RIGHT & LEFT SIDES ADDED SECOND STORY ADDITION
> WIDTHS 13'-10 11/16" ADDED TRIM DETAIL AT WINDOWS IN SIDING
> DEPTH OF SECOND FLR ADDITION DEPTHS
> HEIGHT TO AVERAGE GRADE AT 2 STORY HOUSE
> HEIGHT OF PRIMARY BEDROOM AT AVERAGE GRADE
> & HEIGHT OF LAUNDRY/ BATHROOM AT AVERAGE GRADE

ROMANY ROAD: 800 BLOCK <DILWORTH) 

Ii Ou s c..S 

fJ,�7-//- l�i/ -//.ffl 

(Y\I<. -"\ITT) 

# Mki◄ 

f'{o� c_otJ cr2...t 6fA.Tlr ROMANY RD tDILWORTH>-FROM 1500 MYRTLE AV SOUTHEAST 4 • • SOUTHWEST OF t: MOREHEAD ST ZIP CODE 28203 .. •. , • . , • · •F.ckatrom Richd A @ 372-7116 -4 .' Helma Raymond E @ 334-6596 .. ,., VMcant 7;4"Wolf Charlee M @· 3M-7495 • •• '129· Manaon Edith C Mrs ® 332-4029 • • 735' Morriaon Mildred H Mia ® 372-8477 741- Martindale 'John J ·334-0026 1 ., .. , • • ,,. 747 Renfrow Wm C ® 376-1629 �'l 801 • Dioher Thoa L @ 334-2900 809 No Return • • ••• ...... 813·Ezell Melvin H @) 333-4040 • I 'IS I

dit.e � H� rs -- --- ----817 Green Janice B@ 333-8960'·_, :;'i;;, • - -821 Barberree·Mary: A@ 37[>.1318':,·i·; · 825 Schiwetz .David P @ 333-02ti 8�M � 9avran Jamee H Jr ® 37Ml43 833•W1lhamo Mildred ® - - , -_, · �.;;;.__-+------'-----r--'--:"--._____,,:'-T'-'-'---=--�rr-'---i--'--.....___.,����=....:...:..;..��""-r-R-,,____.L�__;;...:.......;...___ -t-_______ --t � C,anmissbl 

CARLTON AV ENDS· , 901 Helm■ Julian W ® 376-2578 NEIGHBORHOOD SURVEY 

906 Amante David'J ® 333,ao60 •·.H :· 909 Zeller Douglu 333-3625 913 Grey Robt W 333-4070 

+------,f,------,-.,---::-----""'T'""-,------1-----------�---4----.----,-----------+--------------1city directory researcl;l form 

917 Miller Azula E ® 332-6611 921 Garriaon Zelda B ® 333-3320 . 925 Kistler A Lowe ®· 376-2900 .929 Annu Steph M ® 376-2804 ''•':i,. 0''. ;,., 933 Hoppe Adolph B@ 333-2261 935 Myers Baxter J Jr @ 334-8895 !M3 Johnaon Wm W @ 376-1386 •LEXINGTON AV� .. 

• 2al 

ROMANY RD <DILWORTH>-FROM 15<"' / 28 MYRTLE AV S<?_UTHl::AST, � ROMANY ROAD (Dilworth) - From Myrtle SOUTHWEST O, E MOREHEAD ST av southeast to Harding pl, 4 ·1outhwest of EZIP CODE 28.!03 701 Helrm T Edw ® 332-1738 723 Conn Earl L ® 376-6486 729 MaMOn Edith C Mn @ 332-4029 735 Morri&0n Eme•t A ® 332-5863 741 Fink Myrtle V ® 334-5798 747 Renfrow Wm C @)- 375-1629 HO I Dieher Thoa L ® 334-2900 809 Erakine John B ® 333-3381 Erakine Brooksie E Mro mu.a tchr 813 Ezell Melvin H ® 333-4040 ff17 Toney D F Mrs 372�439 ff2 l Barberree Alex K ® 376-2569 825 Schiwetz David P ® 333-0241 829 Pope James C ® 372-o249 833 Crosby Mary B ® 332-7067 CARLTON AV ENDS 901 Helms Julian W ® 376-2578 905 Arant Aubrey Y ® 332-1777 909 A>·cock Richd N ® 334-3872 913 Griswold Collier J @) 334-2098 917 Miller Azula E nune ® 332-5611 921 Garrison Zelda a ® 333-3320 925 Kistler A Lowe· @ 375-2900 929 Biggerstaff Selby C @ 372-6828 933 Hoppe Adolph B ® 333--226, 935 GolT Winnie C Mrs ® 333--�405 943 Vacant . Morehead (Zone 3) • tl4...Helms T Edw@ lJ. ED �-1138 -4J.¥Lonl( Gordon (6) lJ. ED 3-1UO : , 29 Bell 'Faith @ � ED 4·6013 i35 llorrlson Erne•t A;@ lJ. ED 2-:i�d:l �Briggs Lewis ·R lJ. 'ED t-i�:13 �eutrow \Vm C @ lJ. FB 3-lti29 SO! lllsh,r TI10• L@ lJ. ED 4-Z900 �0:1 �:rsklne John B @ lJ. ED 3-3381 Er.kin• Brook•le E llr• mus tchr 

# I � I:: E1.,•ll )leloln H @ lJ. ED 3-4040 �Hla),·z•k Thos J lJ. ED 4-3131 • �l llarherre, .-I.lex K @ lJ. FR l\•256� ! ."ii :,::; :-khiwe-tz 0dvltl P@) 0. E'D 3-02lt ' �!lulr F.dwl11 T@ lJ. �:o :l-007� �rn--h.\ :'-larr B@) 0. EU 2·i0tii • • Carlton av end■ ·!tot fll.'llll."t .lt1IL1n \V �: !10.-•. \.raur A.11hrt:'.\" Y 1!!, lJ,. 1-;u t-tr7i �o,, ll•u·!;er .\ndrew I, @ lJ. l':ll 3-1:lUL :11:1 Smith Trammell O lJ. •:u 2-79:11 !!li )!Iller .\wl• •:@ nun,e lJ. El) �-:.•ill !t:!l (;,lrrl�1,11 F:01ma F. ltr�@ fJ. fi�l> :1-:c�:!fl : :•:!.i n1�tlt 'r Acfot,,hu:-1 (,@ lJ,. t,'I{ :'i-:!!HlO , :•:!'.I Hood Fr�d ..\ � 0. •�n :!-3�-•o : !l:«:l 111py1t• ,.\dolph H ,@ .0. LD :i-:?:!•i L l !�:,.; .,tr u,,u�!as C @ .0. ED :(-:! 10.-. . 94�1 tJ�t'lt•)" Chn:1 L ,j};-..0. Ji:n 3-:t{ !ti 

# l . . ,..,........... 

OMANY ROAD (Dilworth) �From Myrtle av southeut • tQ Harding pl, 4 nuthwest of Morehead iOllJ.H•lms T Edw @ 129lJ.BeU lames A @�)(orrlson Ernest .\ @Ul .. .lJ.Nncns Louise Mra @ &lADlsher Thos L @•eFcren DII.Vld L @ r

lakeney Whlterord 8, .dtlwetz Da,·l<l P @· mtr .. •i:t s�,·1.lJ.Illalr Edwin T @ -Carlton av ends lltW lin1kr ron,tructlon l\o50.\raut ,\ubrcy Y @) �rr Howard J @) . . uln )lary L lira @

# llJ.'J'ho1nas Henry • J @) eth D Barton 1'1tler Adolphu• • L @ oo<l Fred A @Hoppe Adolph B @ 935lJ.Golt Douglna C @) �Torrence Rlchd P @ . • -"tixlngton av anda .I PROPOSED FRONT ELEVATION 

> 1/16” = 1’-0” 
> 2
> EXISTING FRONT ELEVATION
> 1/16” = 1’-0” 
> 1

# 1218 EAST 

# BOULEVARD 

SCOPE OF WORK 

- Building Addition 

Two-story (plus basement) addition, with a footprint of 512SF, 

which will be constructed at the rear of the building 

- Glass Enclosure of Porch 

The proposed porch enclosure will be frameless and conform 

to the shape of the existing architecture 

- Porch Stair Extension 

The top step of the existing porch stair will be raised to 

become flush with the porch decking. The additional stairs will 

be raised 5” and one additional step will be added at the base 

- Raising Existing Dormer Roof by 2 ft. 

The roof of the existing dormer will be raised 2 feet in order 

to provide additional ceiling clearance within the interior 

as the existing height prevents the space inside from being 

occupiable 

- Landscaping Improvements 

Includes the expansion of the existing walkway to provide 

space for temporary seating, the relocation of the existing 

mailbox at the front of the property and upgrading the existing 

signage. All existing foliage will be preserved. 

Principal | Alaa Bou Ghanem 

AIA, NCARB, LEED AP BD+C 

310 East Blvd, Suite 6 

Charlotte, NC 28203 

(office): (980) 999-0213 

(direct): (980) 949-0213 

> 3/32”
> 3/32”

SIDE AND REAR ELEVATIONS -

EXISTING AND PROPOSED 

PROPOSED RIGHT ELEVATION 

1/16” = 1’-0” 

2

EXISTING RIGHT ELEVATION 

1/16” = 1’-0” 

1

EXISTING REAR ELEVATION 

1/16” = 1’-0” 3

PROPOSED REAR ELEVATION 

1/16” = 1’-0” 

43D AERIAL VIEWS -

EXISTING AND PROPOSED 

PROPOSED AXONOMETRIC - SOUTHWEST 



4

EXISTING AXONOMETRIC - SOUTHWEST 

3

PROPOSED AXONOMETRIC - NORTHEAST 



2EXISTING AXONOMETRIC - NORTHEAST 

1

VIEW THE PROPERTY 

YOURSELF: 

https://my.matterport.com/ 

show/?m=28shYoh6YtL
