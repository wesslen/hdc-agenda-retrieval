Title: 

URL Source: https://wesslen.github.io/hdc-agenda-retrieval/data/supplement/2024/agenda-supplement_14feb2024.pdf

Markdown Content:
# Agenda Supplement February 14, 2024 

HDC Meeting 

## Applicant Submitted Information Information Submitted by the Public Porch enclosure examples with vertical windows 

This shows vertical panes with smaller panes at the 

bottom. It could work well on my enclosed porch and 

would allow more of an open view to the porch interior. 

This shows completely open panes, top to bottom, It would 

provide a fully open view of the porch, interior. 

Either of these options would work if the Commissioners prefer a more open look rather than the double window panels 

shown in the plans. I would prefer this kind of open look as well, with a slight preference with the small panes at the bott om. AGENDA SUPPLEMENT 

February 14, 2024 

# Wilmore School Site 

34 Site Plan - Revision History 

W KINGSTON STREET S MINT STREET WEST BOULEVARD PROPERTY LINE A4.01 2A4.01 1A4.01 4A4.01 3SURFACE PARKING - RETAIL AND VISITOR PARKING INTERNAL ACCESS ROAD DEMO SCHOOL ADDITION +4 FLOORS FROM MINT ST AND WEST BLVD EXISTING SCHOOL RESIDENTIAL UNITS +3 FLOORS PARKING ENTRY DEMOED SCHOOL ADDITION RESIDENTIAL POOL COURTYARD +/- 3,500sf GROUND FLOOR RETAIL F.F. @ 1'-6" BELOW LEVEL 1 1A5.01 1A5.01 BUILDING SETBACK 700' 698' 702' 696' 694' 690' 692' 704' 688' 690' 688' 692' 694' 696' 698' 700' 702' 704' 706' 708' 710' 712' 712' 710' 708' 706' + 698.5' + 701.5' + 702' + 704.5' + 692' + 690' 689.5' + 691' + 690' + 2A5.01 EXISTING RESIDENCE EXISTING RESIDENCE EXISTING ENTRY EXISTING ENTRY ASSEMBLY SPACE PRIMARY RESIDENTIAL RETAIL EXISTING TREES TO REMAIN EXISTING WILMORE SIGN TO REMAIN LANDSCAPED RETAIL PLAZA AREA RETAIL EXISTING TREES TO REMAIN NEW TREE TO REPLACE EXISTING EXISTING TREES TO REMAIN EXISTING TREES TO REMAIN EXISTING TREES TO REMAIN EXISTING TREES TO REMAIN HVAC EQUIP. LANDSCAPED AREA AND NEW TREES +/- 4,000sf ASSEMBLY SPACE LANDSCAPED RETAIL PATIO LANDSCAPED AREA AND NEW TREES PARALLEL PARKING SPACES PROPERTY LINE SCREENING, TOWNHOUSES SCREENED TRANSFORMERS AND TRASH AREA, TBD. +3 FLOORS FROM MINT ROOF TERRACES +3 FLOORS FROM PATIO ROOF TERRACE STAIR ACCESS ROOF TERRACES 1700 MINT 417 KINGSTO A4.02 A4.02 +3 FLOORS +3 FLOORS +4 FLOORS +4 FLOORS +3 FLOORS +3 FLOORS +3 FLOORS 

Site Plan 

+4 FLOORS 

+3 FLOORS 

W KINGSTON STREET S MINT STREET WEST BOULEVARD PROPERTY LINE A4.01 2A4.01 1A4.01 4A4.01 3SURFACE PARKING - RETAIL AND VISITOR PARKING INTERNAL ACCESS ROAD DEMO SCHOOL ADDITION +4 FLOORS FROM MINT ST AND WEST BLVD EXISTING SCHOOL RESIDENTIAL UNITS +3 FLOORS FROM MINT PARKING ENTRY DEMOED SCHOOL ADDITION RESIDENTIAL POOL COURTYARD +/- 2,500sf GROUND FLOOR RETAIL 1A5.01 1A5.01 SETBACK 14'-0" KCABTES"0-'41SETBACK 10'-0" BUILDING SETBACK KCABTES"0-'41700' 698' 702' 696' 694' 690' 692' 704' 688' 690' 688' 692' 694' 696' 698' 700' 702' 704' 706' 708' 710' 712' 712' 710' 708' 706' + 698.5' + 701.5' + 702' + 704.5' + 692' + 690' 689.5' + 691' + 2A5.01 66'-0" 52'-0" EXISTING RESIDENCE EXISTING RESIDENCE EXISTING ENTRY EXISTING ENTRY ASSEMBLY SPACE PRIMARY RESIDENTIAL RETAIL EXISTING TREES TO REMAIN EXISTING TREES TO REMAIN EXISTING WILMORE SIGN TO REMAIN LANDSCAPED RETAIL PLAZA AREA RETAIL 33'-0" 25'-0" 40'-0" 15'-0" 53'-6" EXISTING TREES TO REMAIN NEW TREE TO REPLACE EXISTING EXISTING TREES TO REMAIN 38'-3" 29'-1 1/2" 53'-5" EXISTING TREES TO REMAIN EXISTING TREES TO REMAIN EXISTING TREES TO REMAIN HVAC EQUIP. LANDSCAPED AREA AND NEW TREES +/- 4,000sf ASSEMBLY SPACE LANDSCAPED RETAIL PATIO LANDSCAPED AREA AND NEW TREES PARALLEL PARKING SPACES PROPERTY LINE SCREENING, SEE DETAIL TOWNHOUSES 25'-1" 62'-5" 66'-10" 232'-4" SCREENED TRANSFORMERS AND TRASH AREA, TBD. 40'-0" 100'-0" SETBACK FROM N1 ZONING +3 FLOORS FROM MINT 30'-0" 48'-0" 53'-0" 33'-0" 40'-5" ROOF TERRACES +3 FLOORS FROM PATIO ROOF TERRACE STAIR ACCESS ROOF TERRACES A4.03 2A4.03 1A4.03 4A4.03 315'-6" 15'-6" 31'-0" 58'-0" 50'-0" 8'-9" 40'-1 1/4" 62'-0" 43'-0" 1700 MINT 417 KINGSTON 62'-0" 

15 

> +3 FLOORS

+4 FLOORS +4 FLOORS +3 FLOORS 

Last HDC Meeting - December 2023 Current 

35 Elevations - Revision History 

1A5.01 INTERNAL ACCESS ROAD SOUTH MINT STREET BRICK MASONRY FACADE WITH SOLDIER COURSE HEADERS PAINTED LAP SIDING PAINTED LAP SIDING ridge = 728.5' 1st level = 698.5' 37'-0" 33'-2" 727'-0" 723'-2" W KINGSTON AVENUE WEST BLVD STOREFRONT WINDOWS AT RETAIL BRICK MASONRY FACADE WITH SOLDIER COURSE HEADERS OVERSIZED DIVIDED LITE WINDOWS UNIT ENTRY DIRECT TO STREET SETBACK TERRACE W/ PAINTED LAP SIDING PARKING DECK ENTRY CAST STONE BASE 2A5.01 38'-0" 44'-8" 34'-5" INTERNAL ACCESS ROAD SOUTH MINT STREET STOREFRONT AT RETAIL EXISTING SCHOOL HATCH DENOTES 1970'S ADDITION TO BE REMOVED. ORIGINAL FRONTAGE TO BE RESTORED ADAPTIVE REUSE AND RESTORE ORIGINAL SCHOOL BUILDING ADAPTIVE REUSE AND RESTORE AUDITORIUM STONE BASE 34'-2" 35'-0" 46'-2" 38'-0" 

SC A4.01 2 W KINGSTON STREET SC A4.01 1 MINT STREET SC A4.01 3 WEST BOULEVARD 

Last HDC Meeting - December 2023 

INTERNAL ACCESS ROAD SOUTH MINT STREET BRICK MASONRY FACADE WITH SOLDIER COURSE HEADERS PAINTED LAP SIDING PAINTED LAP SIDING 10' 20' 30' 40' ridge = 728.5' 1st level = 698.5' 37'-0" 37'-0" 34'-6" 21'-2" INTERNAL ACCESS ROAD SOUTH MINT STREET STOREFRONT AT RETAIL EXISTING SCHOOL HATCH DENOTES 1970'S ADDITION TO BE REMOVED. ORIGINAL FRONTAGE TO BE RESTORED ADAPTIVE REUSE AND RESTORE ORIGINAL SCHOOL BUILDING ADAPTIVE REUSE AND RESTORE AUDITORIUM STONE BASE 34'-2" 38'-0" 35'-0" 8'-6" 10'-6" 13'-0" W KINGSTON AVENUE WEST BLVD EXISTING SCHOOL ADAPTIVE REUSE AND RESTORE AUDITORIUM 44'-33'-0" 11'-0" 

SC A4.01 2 W KINGSTON STREET SC A4.01 3 WEST BOULEVARD SC A4.01 4 EAST 

Current 

Kingston Ave Front Elevation 

Kingston Ave Front Elevation 

36 Elevations - Revision History 

INTERNAL ACCESS ROAD SOUTH MINT STREET 37'-0" 33'-2" WEST BLVD 

STOREFRONT WINDOWS AT RETAIL 

BRICK MASONRY FACADE WITH 

SOLDIER COURSE HEADERS 

OVERSIZED DIVIDED LITE WINDOWS 

UNIT ENTRY DIRECT TO STREET SETBACK TERRACE W/ PAINTED LAP SIDING PARKING DECK ENTRY CAST STONE BASE 2A5.01 38'-0" 44'-8" 34'-5" 

PROJECT # / 

LOCATION / DATE / DRAWN / 

ELEVATIONS 

23AHI100 11.21.2023 HS 

# A4.01 

CHARLO SCALE: 1" = 20'-0" A4.01 2 W KINGSTON STREET ELEVATION SCALE: 1" = 20'-0" A4.01 1 MINT STREET ELEVATION 

REVIS NO. DESCRIPT 

Last HDC Meeting - December 2023 

Mint St Front Elevation West Blvd Front Elevation 

1A5.01 INTERNAL ACCESS ROAD PAINTED LAP SIDING 10' 20' 30' 40' WICKFORD PLACE ridge = 728.5' 1st level = 698.5' 33'-2" 723'-2" SETBACK T 2A5.01 SOUTH MINT STREET 

STOREFRONT AT RETAIL 

ADAPTIVE REUSE AND RESTORE ORIGINAL SCHOOL BUILDING STONE BASE 34'-2" 35'-0" 46'-2" 38'-0" EXISTING SCHOOL ADAPTIVE REUSE AND RESTORE AUDITORIUM 

TERNAL CCESS OAD SOUTH MINT STREET BRICK MASONRY FACADE WITH SOLDIER COURSE HEADERS PAINTED LAP SIDING PAINTED LAP SIDING 10' 20' 30' 40' 37'-0" 37'-0" 34'-6" 21'-2" WEST BLVD 

STOREFRONT WINDOWS AT RETAIL 

BRICK MASONRY FACADE WITH 

SOLDIER COURSE HEADERS 

OVERSIZED DIVIDED LITE WINDOWS 

UNIT ENTRY DIRECT TO STREET SETBACK TERRACE W/ PAINTED LAP SIDING PARKING DECK ENTRY CAST STONE BASE 37'-6" 33'-5" 45'-2" 44'-2" FACE OF SCHOOL AUDITORIUM BEYOND RETAIL F.F. @ 1'-6" BELOW TYP F.F. 37'-0" 12'-6" 12'-2" 33'-0" 11'-0" INTERNAL ACCESS ROAD SOUTH MINT STREET STOREFRONT AT RETAIL EXISTING SCHOOL HATCH DENOTES 1970'S ADDITION TO BE REMOVED. ORIGINAL FRONTAGE TO BE RESTORED ADAPTIVE REUSE AND RESTORE ORIGINAL SCHOOL BUILDING ADAPTIVE REUSE AND RESTORE AUDITORIUM STONE BASE 34'-2" 38'-0" 35'-0" 8'-6" 13'-0" 

PROJECT # / 

LOCATION / DATE / DRAWN / 

WILMORE 

PRELIMINARY ST ELEVATIONS 

23AHI100 01.20.2024 HS 

# A4.01 

CHARLO AVERY HALL SCALE: 1" = 20'-0" A4.01 2 W KINGSTON STREET ELEVATION SCALE: 1" = 20'-0" A4.01 1 MINT STREET ELEVATION SCALE: 1" = 20'-0" A4.01 3 WEST BOULEVARD ELEVATION 

REVIS NO. DESCRIPT 

PAINTED LAP SIDING SOUTH MINT STREET STOREFRONT AT RETAIL ADAPTIVE REUSE AND RESTORE ORIGINAL SCHOOL BUILDING STONE BASE 34'-2" 38'-0" 35'-0" 8'-6" 10'-6" 13'-0" WEST BLVD EXISTING SCHOOL ADAPTIVE REUSE AND RESTORE AUDITORIUM 33'-0" 11'-0" 

Current 

Mint St Front Elevation West Blvd Front Elevation 

37 Elevations - Revision History 

11A5.01 INTERNAL ACCESS ROAD SOUTH MINT STREET STOREFRONT AT RETAIL EXISTING SCHOOL HATCH DENOTES 1970'S ADDITION TO BE REMOVED. ORIGINAL FRONTAGE TO BE RESTORED ADAPTIVE REUSE AND RESTORE ORIGINAL SCHOOL BUILDING ADAPTIVE REUSE AND RESTORE AUDITORIUM STONE BASE 34'-2" 35'-0" 46'-2" 38'-0" 

W KINGSTON 

AVENUE 

WEST BLVD EXISTING SCHOOL ADAPTIVE REUSE AND RESTORE AUDITORIUM 2A5.01 44'-8" 

SC A4.01 3 WEST BOULEVARD SC A4.01 4 EAST 

Last HDC Meeting - December 2023 

W KINGSTON 

AVENUE 

WEST BLVD EXISTING SCHOOL ADAPTIVE REUSE AND RESTORE AUDITORIUM 44'-2" 33'-0" 11'-0" 13'-6" 

SC A4.01 4 EAST 

Current 

East Property Line Side Elevation 

East Property Line Side Elevation 

38 Streetscape Rendering - Kingston Ave from East 

> 39

## Streetscape Rendering - Straight-on View From across Kingston Ave 

> 40

## Streetscape Rendering - View From Far Corner of Mint St and Kingston Ave 

> 41

## Streetscape Rendering - View From Far Corner of Mint St and West Blvd 

> 42

## Streetscape Rendering - Straight-on View From Across West Blvd 

> 43

## Sreetscape Rendering - West Blvd View from East 

> 44

## Townhouses - Kingston Elevation in Context 

> 45

15’6” 15’6” 15’6” 15’6” 

15’6” 15’6” 

11’-0” 11’-0” 

GAP GAP 

31’ 

62’ 

## Townhouses - Details and Spacing at Kingston Ave 

W KINGSTON STREET 

A4.01 2PARKING ENTRY 1A5.01 KCABTES"0-'41690' 688' 688' 692' 694' 696' 698' 700' 702' 704' + 692' + 690' 689.5' + 66'-0" 53'-6" EXISTING TREES TO REMAIN NEW TREE TO REPLACE EXISTING EXISTING TREES TO REMAIN 8’-0” DEEP ENTRY PORCHES EXISTING TREES TO REMAIN TOWNHOUSES 40'-0" 30'-0" 33'-0" 40'-5" 58'-0" 52'-0" 40'-1 1/4" 62'-0" 43'-0" 1700 MINT 417 KINGSTON A4.02 46'-0" 42'-0" 40'-0" 21'-0" 13'-0" 25'-2" 8'-6" 24'-0 1/4" +3 FLOORS +3 FLOORS 91'-4 1/2" 11'-0" 62'-0" 11'-0" 62'-0" 11'-0" 56'-0" 15'-6" 15'-6" 15'-6" 15'-6" 31'-0" 31'-0" 44'-2" 19'-5" 24'-10" 22'-4" 7'-6" 22'-4" 29'-3" '-0" 18'-4 1/2" 13'-6 1/4" 17'-11 1/4" 71'-6" 69'-6" 13'-11" 25'-9 1/2" 12'-0" 14'-8" 

## Site Plan 

> 8'-0"

+3 FLOORS 

62’ - 0” 

> 52 - 0”

62’ - 0” 61’ - 0” 32 - 6” 

## 1234

46 W KINGSTON STREET 

A4.01 2PARKING ENTRY 1A5.01 KCABTES"0-'41690' 688' 688' 692' 694' 696' 698' 700' 702' 704' + 692' + 690' 689.5' + 66'-0" 53'-6" EXISTING TREES TO REMAIN NEW TREE TO REPLACE EXISTING EXISTING TREES TO REMAIN 8’-0” DEEP ENTRY PORCHES EXISTING TREES TO REMAIN TOWNHOUSES 40'-0" 30'-0" 33'-0" 40'-5" 58'-0" 52'-0" 40'-1 1/4" 62'-0" 43'-0" 1700 MINT 417 KINGSTON A4.02 46'-0" 42'-0" 40'-0" 21'-0" 13'-0" 25'-2" 8'-6" 24'-0 1/4" +3 FLOORS +3 FLOORS 91'-4 1/2" 11'-0" 62'-0" 11'-0" 62'-0" 11'-0" 56'-0" 15'-6" 15'-6" 15'-6" 15'-6" 31'-0" 31'-0" 44'-2" 19'-5" 24'-10" 22'-4" 7'-6" 22'-4" 29'-3" '-0" 18'-4 1/2" 13'-6 1/4" 17'-11 1/4" 71'-6" 69'-6" 13'-11" 25'-9 1/2" 12'-0" 14'-8" 

## Site Plan 

> 8'-0"

+3 FLOORS 

## Townhouses - Details at Kingston Ave 

47 Townhouses - Grouping 1 Detail Elevation - Front / Kingston Ave Note: All Materials to Be Traditional 

8’-0” Entry Porch 

with Standing 

Seam Metal Roof 

Painted Wood 

Column with Brick 

Base 

1x7 Lap Siding at 

Lower Floors 

1x4 Lap Siding at 

Upper Floors 

Asphalt Shingle 

Roof, Min. 3/12 

Slope 

Smaller 4 over 4 

Windows, Shift in 

Scale Upper Floor 

Soldier Course Brick 

at Window Header 

6 over 1 Windows 

> 48

## Townhouses - Grouping 1 Detail Elevation - East / Property Line 

Cast Stone Base 

Modular Brick at 

Lower Floors 

1x4 Lap Siding at 

Upper Floors 

Asphalt Shingle 

Roof, Min. 3/12 

Slope 

Smaller 4 over 4 

Windows, Shift in 

Scale Upper Floor 

Soldier Course Brick 

at Window Header 

6 over 1 Windows 

Note: All Materials to Be Traditional 

> 49

## Townhouses - Grouping 2 Detail Elevation - Front / Kingston Ave 

8’-0” Entry Porch 

with Standing 

Seam Metal Roof 

Painted Wood 

Column with Brick 

Base 

1x7 Lap Siding at 

Lower Floors 

1x4 Lap Siding at 

Upper Floors 

Asphalt Shingle 

Roof, Min. 3/12 

Slope 

Smaller 4 over 4 

Windows, Shift in 

Scale Upper Floor 

Soldier Course Brick 

at Window Header 

6 over 1 Windows 

Cast Stone Base 

Note: All Materials to Be Traditional 

> 50

## Townhouses - Grouping 3 Detail Elevation - Front / Kingston Ave Note: All Materials to Be Traditional 

8’-0” Entry Porch 

with Standing 

Seam Metal Roof 

Painted Wood 

Column with Brick 

Base 

1x7 Lap Siding at 

Lower Floors 

1x4 Lap Siding at 

Upper Floors 

Asphalt Shingle 

Roof, Min. 3/12 

Slope 

Smaller 4 over 4 

Windows, Shift in 

Scale Upper Floor 

Soldier Course Brick 

at Window Header 

6 over 1 Windows 

Cast Stone Base 

> 51

## Townhouses - Grouping 4 Detail Elevation - Front / Kingston Ave Note: All Materials to Be Traditional 

8’-0” Entry Porch 

Turning Corner 

Ashalt Shingle 

Roof, Min 3/12 

Slope 

2x Townhouses Single Townhouse 

Facing Mint St 

Dormer with 

Recessed 

Terrace 

> 52

## Townhouses - Grouping 4 Detail Elevation - West / Mint Blvd Note: All Materials to Be Traditional 

8’-0” Entry Porch 

with Standing 

Seam Metal Roof 

Painted Wood 

Column with Brick 

Base 

Modular Brick 

Asphalt Shingle 

Roof, Min. 3/12 

Slope 

Recessed Terrace with 

Painted Aluminum 

Gaurdrail 

6 over 1 Windows 

Cast Stone Base 

> 53

Concealed 

Structured parking 

1x7 Lap Siding at 

Lower Floors 

1x4 Lap Siding at 

Upper Floors 

Facade Reveal 

or Change in 

Material 

at 15.5’ Intervals 

Facade Steps at 

15.5’ / 31’ Intervals 

Pop Up Dor -

mer for Roof 

Line Variation 

Asphalt Shingle 

Roof, 3/12 Slope 

Smaller 4 over 4 

Windows, Shift 

in Scale Upper 

Floor 

6 over 1 Windows 

19’ Front Yard 

6’ Sidewalk 

15’ Planter Strip 

(At Typ) 

Covered Front 

Entries with 

Balcony Above 

Partial Section Along Kingston 

## Townhouses - Architectural Details at Kingston Ave Note: All Materials to Be Traditional 

> 54 8"

1'-6" 15° 

AveryHall 

WILMORE SCHOOL CHARLOTTE, NC 282 02/06/2024 

DATE 

TOWNHOUSE DETAIL 497 CARROLL STREE BROOKLYN, NY 11215 

TOWNHOUSE PROJECT INFORMAT DRAWING NAME 

SOFFIT 4" 5'-0" 

DORMERS & EAVES 

ALUMINUM CLAD EXTERIOR WINDOWS DESIGN INTENT, MANUFACTURER TBD 

1/2" = 1'-0" 02 

ASPHALT SHINGLE ROOF 3/12 SLOPE 3'-6" 10" 

GENERAL NOTE: 

ALL MATERIALS TO BE TRADITIONAL 

DORMERS & EAVES 

> 1'-0"

SOLDIER COURSE BRICK HEADER 

WINDOWS 

01 

> 6'-6" 4"

1/4" = 1'-0" 1/4" = 1'-0" 

4" 1'-0" 2'-6" RAFTER ROWLOCK SILL 4" 4" MODULAR BRICK DRIP EDGE 4" FASCIA 1" X 7" LAP SIDING PAINTED WOOD WINDOW TRIM 

03 

FRIEZE BOARD 

## Townhouses - Architectural Details Note: All Materials to Be Traditional 

55 7" 

TOWNHOUSE DETAIL 

DATE TOWNHOUSE AveryHall 

497 CARROLL STREE BROOKLYN, NY 11215 

PROJECT INFORMAT DRAWING NAME 

WILMORE SCHOOL CHARLOTTE, NC 282 02/06/2024 

> 5'-11"

1'-0" 

ENTRANCE PORCHES GENERAL NOTE: 

ALL MATERIALS TO BE TRADITIONAL 

05 

> 7'-6"

ENTRANCE DOORS 

1'-4" 3'-2" 

04 

2'-8" PAINTED WOOD COLUMN 5'-0" 2'-7" PAINTED WOOD EXTERIOR ENTRY DOOR DESIGN INTENT, MANUFACTURER TBD 1'-4" 2'-4" 12'-0" 4'-0" STANDING SEAM METAL PORCH ROOF 2'-1" 8'-0" WALL SCONCE SOLDIER COURSE BRICK HEADER 7'-11" 9'-10" BRICK BASE 

1/4" = 1'-0" 

CAST STONE BASE ROWLOCK SILL 

1/4" = 1'-0" 

ALUMINUM CLAD EXTERIOR WINDOWS DESIGN INTENT, MANUFACTURER TBD 

## Townhouses - Architectural Details Note: All Materials to Be Traditional 

56 Gateway - Mint St Detail Elevation 

1x4 Lap Siding 

at 4th Fl and 

Notch 

Variation in 

Roof Parapet 

Height 

In and Out Brick 

Coursing at Ground 

Floor, Similar To 

Calvary Church 

Building 

Cast Stone Band at 

First Floor 10’x10’ Notch Steps in Building 

Massing 

Smaller 6 over 1 

Windows at 4th 

Floor 

Cast Stone Parapet 

with Variation in 

Height 

Note: All Materials to Be Traditional 

> 57

## Gateway - West Blvd Detail Elevation 

Painted Aluminum 

Retail Storefront 10’x10’ Notch 

Smaller 6 over 1 

Windows at 4th 

Floor 

Cast Stone Parapet with 

Variation in Height 

Oversized Divided 

Lite Windows to 

Match School 

Cast Stone Band at 

First Floor 

Note: All Materials to Be Traditional 

> 58

Oversized Divided Lite 

Windows to Match School 

11’-0” 

22’-0” - 23’-6” 

11’-2” - 12’-2” 

Modular Brick to Match School 

2’ Step in Massing 

1x4 Lap Siding at Upper Floors 

(And Notch) 

Smaller 6 over 1 Windows, 

Shift in Scale Upper Floor 

Soldier Course Brick at Window 

Header 

Alternating in and out Brick 

Coursing, Similar to Ground Fl 

of Calvary Church Building 

Cast Stone Base 

Note: All Materials to Be Traditional Gateway - Architectural Details at Mint St 

Cast Stone Parapet Band with 

Variation in Height 

Cast Stone Band at First Floor 

Partial Section Along Mint 59 Gateway - Architectural Details at West Blvd 

13’-0” 

22’-0” - 23’-6” 

11’-2” - 12’-2” 

Oversized Divided Lite 

Windows to Match School 

Modular Brick to Match 

School 

1x4 Lap Siding at Upper Floors 

(And Notch) 

Smaller 6 over 1 Windows, 

Shift in Scale Upper Floor 

Soldier Course Brick at Window 

Header 

Cast Stone Cladding at 

Retail Piers 

Painted Aluminum Retail 

Storefront 

Cast Stone Base 

Landscaped Retail Patio with 

Pavers 

Cast Stone Parapet Band with 

Variation in Height 

Cast Stone Band at First Floor 

Note: All Materials to Be Traditional 

Partial Section Along West Blvd 

> 60 1'-0" 6'-2"

4" VARIES 2'-0" VARIES 4" 4" 4" 7'-0"  2'-0" 1'-8" VARIES 3" 2'-4" 

02/09/2024 

AveryHall 

GATEWAY DETAILS 497 CARROLL STREE BROOKLYN, NY 11215 

DATE PROJECT INFORMAT DRAWING NAME 

WILMORE SCHOOL CHARLOTTE, NC 282 

GATEWAY D 

1" x 4" LAP SIDING 

1/4" = 1'-0" 

PAINTED WOOD TRIM PARAPET SOLDIER COURSE BRICK HEADER 

PARAPET & SETBACK TERRACES GROUND LEVEL & ENTRY DOORS 

BRICK 3/4" BUMP IN CAST STONE BELT COURSE 4 COPLANAR BRICK COURSINGS CAST STONE BELT COURSE CAST STONE BASE 1 BRICK COURSING, RECESSED 3/4" CAST STONE PARAPET 

01 02 

MODULAR BRICK PAINTED ALUMINUM RAILING 

GENERAL NOTE: 

ALL MATERIALS TO BE TRADITIONAL 

1/4" = 1'-0" 

ROWLOCK SILL CAST STONE BASE PAINTED WOOD WINDOW TRIM ALUMINUM CLAD EXTERIOR WINDOWS DESIGN INTENT, MANUFACTURER TBD 

CALVARY CHURCH BUILDING, BRICK DETAIL REFERENCE 

## Gateway - Architectural Details Note: All Materials to Be Traditional 

61 Current State of the Historic Wilmore School 

Extreme Differential Settlement - AKA Sinking Excessive Basement Water Damage and Corrosion Excessive Vandalism, Theft and Safety Hazard 

> 62

# Thank You! SCARBOROUGH FAMILY A L B D E S I G N S T U D I O 

> 63

## Information Submitted by the Public 

Sam Skains and Michael Menchaca 

417 W Kingston Av Proposed Development – “Gateway” Apartment Building 

> 46.5 ft above grade
> 38 ft above grade

## Proposed Development – “Gateway” Apartment Building Proposed tower will be 

significantly visible from 

different pedestrian 

viewpoints. 

This will undermine the 

Historic Wilmore School 

and the context of the 

neighborhood. 

## Proposed Development – “Gateway” Apartment Building 

(34 FT) Proposed Development – Townhomes on W. Kingston Scale of the Proposed Development on West Kingston does NOT respect immediate historic context of 

neighboring homes. 

The 4 Story “Gateway” will be significantly visible on Kingston Ave. 

## Proposed Development – Townhomes on W. Kingston Information Submitted by the Public        

> Grayson Hawkins
> 1701 Merriman AvFrom: Grayson Hawkins
> To: Harpst, Kristina
> Subject: [EXT]agenda #9 424-428 West Bv (PID 11907801)
> Date: Tuesday, February 13, 2024 12:13:01 PM
> EXTERNAL EMAIL : This email originated from the Internet. Do not click any images, links or open any attachments unless you recognize and trust the sender and know the content is safe. Please click the Phish Alert button to forward the email to Bad.Mail.

Kristi, 

Hey hope all is well. I believe I missed the deadline for letters of support for agenda #9 but I plan on speaking tomorrow so this note may not be necessary. 

I have been volunteering in the Wilmore Neighborhood since 2020. My initial responsibilities were in regard to land use and development. The overwhelming ask by the community at that time was to advocate for the preservation of the Historic Wilmore School in some capacity which was assumed would be done as part of a larger mixed-use project. At the start of the CMS sale process, I was again asked to lobby CMS to choose a plan that included the preservation of the historic Wilmore School. 

Due to volunteering as WNA president, I have been hesitant to speak up since I do not want to make any broad representations on behalf of the neighborhood when there are individuals with varying degrees of opinion. Speaking on behalf of myself as a Wilmore Neighbor, I think the project currently proposed is incredibly thoughtful, both in terms of historic preservation and architecture, and would be a great outcome for the Wilmore and Charlotte Community. The opposition and HDC have done an incredible job scaling down and enhancing the project. If passed, this will serve as a case study for how the HDC and concerned individuals can work with developers, public entities, community members and historic landmarks to deliver an exceptional outcome. The combination of preserving the school, the subgrade parking and the architecture make the Avery Hall plan extremely compelling. This project is one of the more impressive examples of urban design and placemaking that I have seen anywhere and should be the type of project that receives awards. The historical elements can be admired for generations and nothing in this project resembles the commodity merchant-built product we see elsewhere in Charlotte. There is not a project in Charlotte that has this level design and this low of density while including subgrade parking. I am surprised a project of this quality and scale is financially feasible given the condition of the school building and the cost of construction. My impression is that the developer is going above and beyond to deliver a quality project for the neighborhood. As the central element in the neighborhood, the improved walkability of the area and overall aesthetic would be a great improvement. 

I am aware of the HDC’s strict set of guidelines when reviewing a project and I believe that this project should be passed as currently presented. 

For anyone on the HDC who is unsure about their position, I ask that they consider the significance of preserving and incorporating the historic Wilmore School within the Wilmore Historic District. 

I support agenda #9, 424-428 West Bv (PID 11907801), and ask the HDC to support this project. 

> Thank you,

Grayson Hawkins Mobile: 919-219-9928 HDC Exterior Photos 

# 201 Grandin Road 

Design Presentation: 02/13/2024 v. 1.0 

Copyright 2023. Cluck Design Collaborative. All Rights Reserved. 201 Grandin Road 

Final Photos of Completed Project 201 Grandin Road 

Final Photos of Completed Project 201 Grandin Road 

Final Photos of Completed Project 201 Grandin Road 

Final Photos of Completed Project 201 Grandin Road 

Final Photos of Completed Project
