Title: HDC_2020_06_JuneBusiness_Minutes.pdf

URL Source: https://wesslen.github.io/hdc-agenda-retrieval/data/minutes/2020/hdc_2020_06_junebusiness_minutes.pdf

Markdown Content:
HISTORIC DISTRICT COMMISSION VIRTUAL BUSINESS MEETING JUNE 10, 2020, ROOM 267 + WebEx MINUTES MEMBERS PRESENT: Mr. Jim Haden (Chairperson) Ms. Kim Parati (Vice Chairperson) Ms. Jessica Hindman (2 nd Vice Chairperson) Mr. Chris Barth Ms. Nichelle Bonaparte Mr. PJ Henningson Mr. Jim Jordan Ms. Christa Lineberger Mr. Chris Muryn Mr. John Phares Mr. Damon Rumsch Ms. Jill Walker MEMBERS ABSENT: NONE OTHERS PRESENT: Ms. Kristi Harpst, Administrator of the Historic District Ms. Candice Leite, Staff to the Historic District Commission Ms. Cindy Kochanek, Staff to the Historic District Commission Ms. Linda Keich, Clerk to the Historic District Commission Ms. Andrea Leslie-Fite, Senior Assistant City Attorney Mr. Maxx Oliver, Planning, Design & Development Staff Mr. Rusty Gibbs, representative for VanLandingham Townhomes Ms. Panchali Sau, representative for VanLandingham Townhomes Mr. Tim Finein, representative for VanLandingham Townhomes With a quorum present, Chairman Haden called the June WebEx Virtual Business Meeting of the Historic District Commission to order at 1:05 am. Chairman Haden began the meeting by introducing the Staff, the Commissioners, and explaining the meeting’s procedure. The Historic District Commission is a quasi-judicial body, no public hearings will be held during today’s virtual meeting. Staff will present a brief summary of the items on the agenda. Any Commissioner wishing to request the floor on a meeting topic will use the WebEx “raise your hand” tool to be recognized by Staff or the Chair. Chairman Haden asked that everyone please mute your audio when not speaking, use only one source of audio (computer OR phone), and do not place telephones on hold. Chairman Haden also asked attendees to turn off or silent all electronic devices and not to speak over the person talking. Agenda: Pre-application Review, VanLandingham Townhomes – New Construction, Plaza Midwood Approve February meeting minutes 

WWZKsDZ,ϭϬ͕ϮϬϮϭ Approve May Business meeting minutes FY2021 Officers Rules of Procedure updates Design Guidelines review/discussion 

x Oaklawn Park 

x Phase III, contract status Update Adjourn 

WZͲWW>/d/KEWZK:dZs/t 

VanLandingham - Townhomes Mr. Rusty Gibbs, Ms. Panchali Sau, and Mr. Tim Finein gave a presentation on the design of proposed townhomes to receive feedback from the Commission. Dd/E'D/Ehd^WWZKs> 

Ms. Hindman moved to approve the February 12, 2020, Historic District Commission Meeting minutes, Mr. Rumsch seconded, and the vote was unanimous. Ms. Hindman moved to approve the May 13, 2020, Historic District Commission Virtual Business Meeting minutes, Mr. Rumsch seconded, and the vote was unanimous. 

&/^>zZϮϬϮϭK&&/Z^ 

Ms. Hindman moved to approve the proposed slate for Ms. Parati as Chairperson, Mr. Henningson as Vice-Chairperson and Ms. Hindman as Second Vice-Chairperson, Mr. Rumsch seconded, and the vote was unanimous. 

Zh>^K&WZKhZhWd^ 

Ms. Harpst gave a presentation to the Commission on the upcoming changes to the Rules of Procedures. She stated the NC General Statutes are being redone which will affect the Planning Department internally. There are no major changes to Historic Districts. 

^/'E'h/>/E^K<>tEWZ< 

Ms. Harpst gave a presentation to the Commission on the Oaklawn Park Supplement to the Design Guidelines for review and feedback. The Commission had a discussion and provided feedback to staff. Ms. Harpst informed the commission about the upcoming Charlotte Preservation Awards. Ms. Parati shared that Wesley Heights had an Art Walk Event to bring the community together during COVID-19 social distancing. Ms. Harpst told the Commission about a resource called Charlottecitytoolkit.com that can be given to community members interested in looking up information about their homes. She also informed them that the Charlotte Mecklenburg Library has 5-minute history series on Oaklawn Park History South given by Tom Hanchett. Ms. Harpst let the Commission know that Tom Hanchett put together History South walking tours because of social distancing. Recognition was given to Commissioner John Phares for his three years of service to Historic District Commission. Mr. Haden Adjourned the meeting at 1:45 PM. Linda Keich, Clerk to the Board
